{{/*
Expand the name of the chart.
*/}}
{{- define "dify.name" -}}
{{- default .Chart.Name | toString | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dify.fullname" -}}
{{- $name := default .Chart.Name }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dify.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dify.labels" -}}
helm.sh/chart: {{ include "dify.chart" . }}
{{ include "dify.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

###
{{- define "dify.labelsNew" -}}
{{- $root := . -}}
{{- $workload := "" -}}
{{- if .root -}}
  {{- $root = .root -}}
  {{- $workload = .workload | default "" -}}
{{- end }}
helm.sh/chart: {{ include "dify.chart" $root }}
{{- /* selector labels */ -}}
{{- if $workload }}
{{ include "dify.selectorLabelsNew" (dict "root" $root "workload" $workload) }}
{{- else }}
{{ include "dify.selectorLabels" $root }}
{{- end }}
{{- if $root.Chart.AppVersion }}
app.kubernetes.io/version: {{ $root.Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ $root.Release.Service }}
{{- end }}
###

{{/* labels defined by user*/}}
{{- define "dify.ud.labels" -}}
{{- if .Values.labels }}
{{- toYaml .Values.labels }}
{{- end -}}
{{- end -}}

{{/* annotations defined by user*/}}
{{- define "dify.ud.annotations" -}}
{{- if .Values.annotations }}
{{- toYaml .Values.annotations }}
{{- end -}}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "dify.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dify.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

###
{{- define "dify.selectorLabelsNew" -}}
{{- $root := .root -}}
{{- $workload := .workload -}}

{{- $defaultName := include "dify.name" $root -}}
{{- $defaultInstance := $root.Release.Name -}}

{{- $workloadValues := index $root.Values $workload | default dict -}}
{{- $override := index $workloadValues "selectorLabels" | default dict -}}

app.kubernetes.io/name: {{ default $defaultName (get $override "app.kubernetes.io/name") }}
app.kubernetes.io/instance: {{ default $defaultInstance (get $override "app.kubernetes.io/instance") }}

{{- end }}
###

{{/*
Create the name of the service account to use
*/}}
{{- define "dify.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "dify.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}



{{- define "dify.redis.svc" -}}
{{- printf "%s-redis-master" .Release.Name }}
{{- end }}

{{- define "dify.redis.dsn" -}}
{{- if .Values.externalRedis.enabled -}}
  {{- $user := .Values.externalRedis.username -}}
  {{- $pass := .Values.externalRedis.password -}}
  {{- $db := .Values.externalRedis.db | default 0 -}}
  {{- $useSSL := .Values.externalRedis.useSSL | default false -}}
  {{- if .Values.externalRedis.sentinel.enabled -}}
    {{- $nodes := .Values.externalRedis.sentinel.nodes | default "" -}}
    {{- $svc := .Values.externalRedis.sentinel.serviceName -}}
    {{- $proto := ternary "rediss+sentinel" "redis+sentinel" $useSSL -}}
    {{ $proto }}://{{- if $user -}}
{{- $user }}:{{ $pass }}@
{{- else if $pass -}}
:{{ $pass }}@
{{- end -}}{{ $nodes }}/{{ $db }}?sentinelService={{ $svc }}
  {{- else if .Values.externalRedis.cluster.enabled -}}
    {{- $nodes := .Values.externalRedis.cluster.nodes | default "" -}}
    {{- $proto := ternary "rediss+cluster" "redis+cluster" $useSSL -}}
    {{ $proto }}://{{- if $user -}}
{{- $user }}:{{ $pass }}@
{{- else if $pass -}}
:{{ $pass }}@
{{- end -}}{{ $nodes }}/{{ $db }}
  {{- else -}}
    {{- $host := .Values.externalRedis.host | default "localhost" -}}
    {{- $port := .Values.externalRedis.port | default 6379 -}}
    {{- $proto := ternary "rediss" "redis" $useSSL -}}
    {{ $proto }}://{{- if $user -}}
{{- $user }}:{{ $pass }}@
{{- else if $pass -}}
:{{ $pass }}@
{{- end -}}{{ $host }}:{{ $port }}/{{ $db }}
  {{- end -}}
{{- else if .Values.redis.enabled -}}
  {{- $pass := .Values.redis.global.redis.password -}}
  {{- $svc := include "dify.redis.svc" . -}}
  redis://:{{ $pass }}@{{ $svc }}:6379/3
{{- else -}}
  ""
{{- end -}}
{{- end }}
